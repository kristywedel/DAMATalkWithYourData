from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel
import sqlite3
import json
import faiss
import torch
import numpy as np
from pathlib import Path
from typing import Dict, Optional, List
from sentence_transformers import SentenceTransformer
from ctransformers import AutoModelForCausalLM

# Initialize FastAPI app
app = FastAPI(title="Coffee Shop Chatbot")

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global variables for model instances
_llm = None
_embedding_model = None
_faiss_index = None
_product_ids = None

# Pydantic models for request/response validation
class ChatRequest(BaseModel):
    query: str
    max_results: Optional[int] = 3

class ChatResponse(BaseModel):
    response: str
    context: Dict

def get_embedding_model():
    """Initialize and return the sentence transformer model"""
    global _embedding_model
    if _embedding_model is None:
        _embedding_model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
    return _embedding_model

def get_llm():
    """Initialize and return the LLM"""
    global _llm
    if _llm is None:
        _llm = AutoModelForCausalLM.from_pretrained(
            'TheBloke/Llama-2-7B-Chat-GGUF',
            model_file='llama-2-7b-chat.Q4_K_M.gguf',
            model_type='llama',
            max_new_tokens=256,
            context_length=2048,
            gpu_layers=0  # Set higher if you have GPU memory available
        )
    return _llm

def initialize_faiss():
    """Initialize FAISS index with product descriptions"""
    global _faiss_index, _product_ids
    
    if _faiss_index is not None:
        return _faiss_index, _product_ids

    # Connect to SQLite database
    conn = sqlite3.connect('products.db')
    cursor = conn.cursor()
    
    # Get all products
    cursor.execute('SELECT id, description FROM products')
    products = cursor.fetchall()
    
    # Get embeddings for descriptions
    embedding_model = get_embedding_model()
    descriptions = [prod[1] for prod in products]
    embeddings = embedding_model.encode(descriptions)
    
    # Initialize FAISS index
    dimension = embeddings.shape[1]
    _faiss_index = faiss.IndexFlatL2(dimension)
    _faiss_index.add(np.array(embeddings).astype('float32'))
    
    # Store product IDs for later reference
    _product_ids = [prod[0] for prod in products]
    
    conn.close()
    return _faiss_index, _product_ids

def get_related_entities(cursor, entity: str, depth: int = 2) -> List[Dict]:
    """Recursively query related entities from the database"""
    if depth <= 0:
        return []

    results = []
    
    # Query both directions in relationships table
    cursor.execute('''
        SELECT entity1, relationship, entity2 
        FROM relationships 
        WHERE entity1 = ? OR entity2 = ?
    ''', (entity, entity))
    
    relations = cursor.fetchall()
    
    for rel in relations:
        entity1, relationship, entity2 = rel
        related_entity = entity2 if entity1 == entity else entity1
        
        # Add current relationship
        results.append({
            'entity': related_entity,
            'relationship': relationship,
            'depth': depth
        })
        
        # Recursively get related entities
        nested_relations = get_related_entities(cursor, related_entity, depth - 1)
        results.extend(nested_relations)
    
    return results

def query_faiss(query: str, top_k: int = 3) -> List[Dict]:
    """Query FAISS index for similar products"""
    # Initialize if not already done
    faiss_index, product_ids = initialize_faiss()
    
    # Get query embedding
    embedding_model = get_embedding_model()
    query_embedding = embedding_model.encode([query])
    
    # Search FAISS index
    distances, indices = faiss_index.search(
        np.array(query_embedding).astype('float32'), 
        top_k
    )
    
    # Get product details from database
    conn = sqlite3.connect('products.db')
    cursor = conn.cursor()
    
    results = []
    for idx, distance in zip(indices[0], distances[0]):
        product_id = product_ids[idx]
        
        # Get product details
        cursor.execute('SELECT name, description, category FROM products WHERE id = ?', 
                      (product_id,))
        product = cursor.fetchone()
        
        if product:
            results.append({
                'name': product[0],
                'description': product[1],
                'category': product[2],
                'similarity_score': float(1 / (1 + distance))
            })
    
    conn.close()
    return results

def get_context(query: str) -> Dict:
    """Aggregate context from FAISS and database"""
    # Get similar products
    similar_products = query_faiss(query)
    
    # Get related entities for each product
    conn = sqlite3.connect('products.db')
    cursor = conn.cursor()
    
    related_entities = []
    for product in similar_products:
        entities = get_related_entities(cursor, product['name'])
        related_entities.extend(entities)
    
    conn.close()
    
    return {
        'products': similar_products,
        'related_entities': related_entities
    }

def generate_response(context: Dict, query: str) -> str:
    """Generate a response using the LLM"""
    model = get_llm()
    
    # Format products and related entities clearly
    products_text = "\n".join([
        f"- {p['name']}: {p['description']} (Category: {p['category']})"
        for p in context.get('products', [])
    ])
    
    relations_text = "\n".join([
        f"- {r['entity']} is {r['relationship']} {r.get('depth', '')} steps away"
        for r in context.get('related_entities', [])
    ])
    
    # Construct prompt for Llama-2-Chat
    prompt = f"""<s>[INST] You are a helpful coffee shop assistant. Use the following information to answer the customer's question.

Available Products:
{products_text}

Related Information:
{relations_text}

Customer Question: {query}

Instructions:
- Only use information from the context above
- If you're not sure about something, say so
- Keep the response focused and concise
- Don't make up information [/INST]"""

    # Generate response
    response = model(
        prompt,
        max_new_tokens=150,
        temperature=0.7,
        top_p=0.95,
        repetition_penalty=1.15
    )
    
    # Clean up response
    response = response.split("[/INST]")[-1].strip()
    if "Customer:" in response:
        response = response.split("Customer:")[0].strip()
    if "Assistant:" in response:
        response = response.split("Assistant:")[-1].strip()
        
    return response

def setup_database():
    """Initialize database with products and relationships"""
    try:
        # Load data from JSON
        with open('data.json', 'r') as f:
            data = json.load(f)
        
        # Connect to SQLite
        conn = sqlite3.connect('products.db')
        cursor = conn.cursor()
        
        # Create tables
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS products (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT UNIQUE,
                description TEXT,
                category TEXT
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS relationships (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity1 TEXT,
                relationship TEXT,
                entity2 TEXT,
                UNIQUE(entity1, relationship, entity2)
            )
        ''')
        
        # Insert products
        for product in data.get('products', []):
            cursor.execute('''
                INSERT OR REPLACE INTO products (name, description, category)
                VALUES (?, ?, ?)
            ''', (
                product.get('name', ''),
                product.get('description', ''),
                product.get('category', '')
            ))
        
        # Insert relationships
        for relation in data.get('relationships', []):
            cursor.execute('''
                INSERT OR REPLACE INTO relationships (entity1, relationship, entity2)
                VALUES (?, ?, ?)
            ''', (
                relation.get('entity1', ''),
                relation.get('relationship', ''),
                relation.get('entity2', '')
            ))
        
        conn.commit()
        conn.close()
        return True
    except Exception as e:
        print(f"Database setup error: {e}")
        return False

@app.on_event("startup")
async def startup_event():
    """Initialize all components on startup"""
    try:
        # Setup database
        if not setup_database():
            raise Exception("Failed to setup database")
        
        # Initialize FAISS
        initialize_faiss()
        print("Successfully initialized FAISS index")
        
        # Initialize LLM
        get_llm()
        print("Successfully initialized LLM")
        
    except Exception as e:
        print(f"Startup error: {e}")
        raise

@app.get("/", response_class=HTMLResponse)
async def root():
    """Serve the chat interface"""
    return FileResponse('index.html')

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    try:
        # Test database connection
        conn = sqlite3.connect('products.db')
        cursor = conn.cursor()
        cursor.execute('SELECT COUNT(*) FROM products')
        product_count = cursor.fetchone()[0]
        conn.close()
        
        return {
            "status": "healthy",
            "database": "connected",
            "products_count": product_count
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Health check failed: {str(e)}"
        )

@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """Process chat requests and generate responses"""
    try:
        # Validate input
        if not request.query.strip():
            raise HTTPException(
                status_code=400,
                detail="Query cannot be empty"
            )
        
        # Get context from various sources
        context = get_context(query=request.query)
        
        # Generate response using LLM
        response = generate_response(
            context=context,
            query=request.query
        )
        
        return ChatResponse(
            response=response,
            context=context
        )
        
    except sqlite3.Error as e:
        raise HTTPException(
            status_code=500,
            detail=f"Database error: {str(e)}"
        )
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error processing request: {str(e)}"
        )

@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """Handle all unhandled exceptions"""
    return JSONResponse(
        status_code=500,
        content={
            "error": "Internal server error",
            "detail": str(exc)
        }
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app:app",
        host="127.0.0.1",
        port=5000,
        reload=False  # Disable reload to prevent model reloading
    ) 