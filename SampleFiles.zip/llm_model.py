from typing import List, Dict, Any
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline

class LLMModel:
    def __init__(self, model_name: str = "facebook/opt-125m"):
        # Using a smaller model for testing - replace with your preferred model
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForCausalLM.from_pretrained(model_name)
        self.generator = pipeline(
            "text-generation",
            model=self.model,
            tokenizer=self.tokenizer,
            max_length=300,  # Increased max length
            temperature=0.3,  # Lower temperature for more focused responses
            do_sample=True,   # Enable sampling
            top_p=0.9,       # Add top_p sampling
            repetition_penalty=1.2  # Add repetition penalty
        )

    def generate_response(self, 
                         query: str, 
                         products: List[Dict[str, Any]], 
                         relationships: List[Dict[str, Any]]) -> str:
        # Create context from products and relationships
        context = f"Question: {query}\n\n"
        
        if products:
            context += "Most relevant products:\n"
            for i, product in enumerate(products[:2], 1):
                context += f"- {product['name']}: {product['description']}\n"
            
            if relationships:
                context += "\nRelated items:\n"
                for rel in relationships[:2]:
                    context += f"- {rel['entity']} ({rel['relationship']})\n"
        else:
            context += "No specific products found matching your query.\n"
        
        prompt = f"""You are a helpful coffee shop assistant. Use the following information to answer the customer's question.

{context}

Instructions:
1. Provide a clear, direct answer to the question
2. If comparing products, explain your reasoning
3. If you're not sure about something, say so
4. Keep the response focused and concise
5. For strength-related queries, specifically mention caffeine content and flavor intensity
6. DO NOT generate forms or ask for personal information
7. ONLY use information from the provided context
8. DO NOT make up or list generic options - only use the products listed above
9. If comparing strength, specifically reference the product descriptions

Answer:"""
        
        # Generate response
        response = self.generator(prompt, max_length=300, num_return_sequences=1)[0]['generated_text']
        
        # Extract the response part (after "Answer:")
        response = response.split("Answer:")[-1].strip()
        
        # Clean up any remaining prompt text
        if "Instructions:" in response:
            response = response.split("Instructions:")[0].strip()
        
        # Check for invalid responses
        invalid_responses = [
            "reasoning", "answer", "response", "name:", "email", "phone", 
            "form", "please enter", "verification", "message:", "first name:",
            "last name:", "address:", "phone number:", "the strongest coffee in",
            "the world", "the universe", "the galaxy", "1.", "2.", "3.", "4."
        ]
        
        if not response or any(invalid in response.lower() for invalid in invalid_responses):
            # Fallback response if the model fails to generate properly
            if products:
                # Find the strongest coffee based on description keywords
                strength_keywords = ["caffeine", "strong", "bold", "extra-caffeinated", "dark roast"]
                strongest = max(products, key=lambda x: sum(1 for keyword in strength_keywords if keyword in x["description"].lower()))
                response = f"Based on our available products, {strongest['name']} appears to be the strongest option. {strongest['description']}"
            else:
                response = "I apologize, but I couldn't find any specific information about coffee strength in our database."
        
        return response
